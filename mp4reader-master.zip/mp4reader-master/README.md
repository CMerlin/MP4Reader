# mp4reader
lists mp4 boxes and extract MDAT box of a file (Linux/OS X/Windows)
